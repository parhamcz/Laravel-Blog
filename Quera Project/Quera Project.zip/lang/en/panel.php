<?php

return [

    'quera' => 'Quera',
    'made_with' => 'Made By',
    'about_us' => 'About Us',

];

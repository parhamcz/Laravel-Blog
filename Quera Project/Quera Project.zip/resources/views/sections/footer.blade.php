<footer id="footer">
    <div class="container h-100">
        <div class="row h-100">
            <div class="col h-100">
                <div class="float-start">
                    <div class="mt-3">
                        {{ __('panel.made_with') }}  <a href="https://quera.ir"> {{ __('panel.quera') }} </a>
                    </div>
                </div>
                <div class="float-end h-100">
                    <div class="h-100">
                        <x-jet-nav-link href="https://quera.ir" class="mx-2 h-100">
                            {{ __('admin::admin.course') }}
                        </x-jet-nav-link>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
require('./bootstrap');

require('alpinejs');

window.$ = window.jQuery = require('jquery');

// Bootstrap
require('../plugins/bootstrap/js/bootstrap.min');

// Select2
require('../plugins/select2/js/select2.min');

// Tree View
require('../plugins/treeview/js/hummingbird-treeview.min');

window.persianDate = require("persian-date");
<?php

namespace App\Traits;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

trait DataTable
{
    protected static function generateDataTable(Request $request)
    {
        // TODO: Implement
    }
}
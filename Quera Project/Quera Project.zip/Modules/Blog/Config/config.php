<?php

return [
    'name' => 'Blog'
];

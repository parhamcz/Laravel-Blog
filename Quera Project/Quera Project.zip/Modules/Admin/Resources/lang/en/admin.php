<?php

return [

    'count' => ':value Count',
    'list' => ':value List',
    'dashboard' => 'Dashboard',
    'profile' => 'Profile',
    'login' => 'Login',
    'logout' => 'Logout',
    'remember_me' => 'Remember Me',
    'user' => 'User|Users',
    'post' => 'Post|Posts',
    'category' => 'Category|Categories',
    'tag' => 'Tag|Tags',
    'comment' => 'Comment|Comments',
    'create' => 'Create :value',
    'edit' => 'Edit :value',
    'delete' => 'Delete',
    'course' => 'Course',
    'theme' => 'Theme|Themes',

];
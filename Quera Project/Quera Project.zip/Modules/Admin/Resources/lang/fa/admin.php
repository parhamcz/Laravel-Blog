<?php

return [

    'count' => 'تعداد :value',
    'list' => 'لیست :value',
    'dashboard' => 'داشبورد',
    'profile' => 'پروفایل',
    'login' => 'ورود',
    'logout' => 'خروج',
    'remember_me' => 'مرا به خاطر بسپار',
    'user' => 'کاربر|کاربران',
    'post' => 'پست|پست‌ها',
    'category' => 'دسته‌بندی|دسته‌بندی‌ها',
    'tag' => 'تگ|تگ‌ها',
    'comment' => 'نظر|نظرات',
    'create' => 'ایجاد :value',
    'edit' => 'ویرایش :value',
    'delete' => 'حذف',
    'course' => 'دوره',
    'theme' => 'قالب|قالب‌ها',

];